
#ifndef _TYPES_H

#define _TYPES_H

typedef unsigned long long Uint64; /* 64 or more bits */
typedef unsigned long Uint32;	/* 32 or more bits */
typedef unsigned char Uint8;

#endif
